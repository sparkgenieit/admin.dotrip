// src/lib/constants.ts

// Reads NEXT_PUBLIC_API_URL from your .env.local
export const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL;

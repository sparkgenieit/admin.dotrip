import LoginMainContent from './LoginMainContent';

export default function LoginPage() {
  return <LoginMainContent />;
}

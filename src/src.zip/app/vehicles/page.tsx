import VehiclesMainContent from './VehiclesMainContent';

export default function VehiclesPage() {
  return <VehiclesMainContent />;
}
export const metadata = { title: 'Vehicles' };

export default function VehiclesLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
'use client';

import SelectCarsPage from './components/SelectCarsPage';
import BookingForm from './components/BookingForm';
import BookingConfirmation from './components/BookingConfirmation';

export default function AdminBookingMainContent() {
  const dummyBookingId = 101; // Replace with real ID from BookingForm if needed

  return (
    <div className="p-4 space-y-10">
      {/* Booking Form */}
      <div>
        <h2 className="text-xl font-bold mb-2">Booking Form</h2>
        <BookingForm />
      </div>

      {/* Car Selection */}
      <div>
        <h2 className="text-xl font-bold mb-2">Select Car</h2>
        <SelectCarsPage />
      </div>

      {/* Confirmation */}
      <div>
        <h2 className="text-xl font-bold mb-2">Booking Confirmation</h2>
        <BookingConfirmation bookingId={dummyBookingId} />
      </div>
    </div>
  );
}
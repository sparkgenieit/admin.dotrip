
// Types related to admin booking if needed

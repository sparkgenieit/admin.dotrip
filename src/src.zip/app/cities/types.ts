export interface City {
  id?: number;
  name: string;
  logo_url: string;
  status: boolean;
}

// src/app/bookings/AdminBookingMainContent.tsx
'use client';

import React, { useState } from 'react';
import BookingTimeForm from './components/BookingTimeForm';
import SelectCarsPage from './components/SelectCarsPage';
import BookingConfirmation from './components/BookingConfirmation';

//
// ─── (A) TYPES ──────────────────────────────────────────────────────────────────
//
type BookingDetailsFromForm = {
  tripTypeId: number;       // string trip type ID (was string before)
  pickupLocation: string;   // display text "City, State"
  pickupCityId: number;     // numeric city ID
  dropLocation: string;     // display text "City, State"
  dropCityId: number;       // numeric city ID
  pickupDate: string;       // e.g. "2025-06-10"
  pickupTime: string;       // e.g. "14:30"
};

//
// ─── (B) PARENT COMPONENT ─────────────────────────────────────────────────────────
export default function AdminBookingMainContent() {
  // 1) These “raw” booking details come from BookingTimeForm (Search Cabs).
  //    Now includes tripTypeId, pickupCityId, dropCityId (all numeric), plus date/time strings.
  const [bookingDetailsRaw, setBookingDetailsRaw] =
    useState<BookingDetailsFromForm | null>(null);

  // 2) Once a car is clicked inside SelectCarsPage, we store it here:
  const [selectedCar, setSelectedCar] = useState<any>(null);

  // 3) We only render <SelectCarsPage> once “Search Cabs” has been clicked.
  const [showSelectCars, setShowSelectCars] = useState<boolean>(false);

  // 4) We only render <BookingConfirmation> once the user completes the contact/address form.
  const [bookingFormFilled, setBookingFormFilled] = useState<boolean>(false);

  //
  // ─── (C) CALLBACK: called by BookingTimeForm when user clicks “Search Cabs” ──────
  //
  function handleBookingDetailsChange(data: BookingDetailsFromForm) {
    setBookingDetailsRaw(data);

    // Immediately show the “Select Car” grid now that we have valid data:
    setShowSelectCars(true);

    // Reset downstream selections if user does a new search:
    setSelectedCar(null);
    setBookingFormFilled(false);
  }

  //
  // ─── (D) CALLBACK: called by SelectCarsPage when a car card is clicked ───────────
  //
  function handleCarSelect(car: any) {
    setSelectedCar(car);
  }

  //
  // ─── (E) CALLBACK: called by SelectCarsPage when the contact/address form is submitted ─
  //
  function handleFormComplete() {
    setBookingFormFilled(true);
  }

  //
  // ─── (F) RENDER ───────────────────────────────────────────────────────────────────
  //
  return (
    <div className="p-6 space-y-8">
      {/* STEP 1: Search Cabs */}
      <div className="border rounded-md p-4">
        <h2 className="text-xl font-bold mb-3">1) Search Cabs</h2>
        <BookingTimeForm onBookingDetailsChange={handleBookingDetailsChange} />
      </div>

      {/* STEP 2: Select Car (only once “Search Cabs” is clicked) */}
      {showSelectCars && bookingDetailsRaw && (
        <div className="border rounded-md p-4">
          <h2 className="text-xl font-bold mb-3">2) Select Car</h2>
          <SelectCarsPage
            bookingDetails={bookingDetailsRaw}
            onCarSelect={handleCarSelect}
            onFormComplete={handleFormComplete}
          />
        </div>
      )}

      {/* STEP 3: Booking Confirmation (only once the contact/address form is submitted) */}
      {bookingFormFilled && selectedCar && bookingDetailsRaw && (
        <div className="border rounded-md p-4">
          <h2 className="text-xl font-bold mb-3">3) Booking Confirmation</h2>

          {/*
            BookingConfirmation expects:
              {
                pickupDateTime: string;   // e.g. "2025-06-10 14:30"
                fare: number;             // e.g. selectedCar.price
                pickupAddress: string;    // display text (pickupLocation)
                dropAddress: string;      // display text (dropLocation)
              }
            We build that from bookingDetailsRaw + selectedCar.price.
          */}
          <BookingConfirmation
            bookingDetails={{
              pickupDateTime: `${bookingDetailsRaw.pickupDate} ${bookingDetailsRaw.pickupTime}`,
              fare: selectedCar.price,
              pickupAddress: bookingDetailsRaw.pickupLocation,
              dropAddress: bookingDetailsRaw.dropLocation,
            }}
            selectedCar={{
              name: selectedCar.name,
              price: selectedCar.price,
              image: selectedCar.image,
            }}
          />
        </div>
      )}
    </div>
  );
}

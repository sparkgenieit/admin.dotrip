
// Service file if needed in future for admin-booking-specific API calls
import { API_BASE_URL } from '@/lib/constants';

const API_CITY_URL = `${API_BASE_URL}/cities`;
const API_TRIP_TYPE_URL = `${API_BASE_URL}/trip-types`;




/**
 * Retrieve the auth token from localStorage
 */
function getToken() {
  console.log(localStorage.getItem('authToken'));
  return typeof window !== 'undefined' ? localStorage.getItem('authToken') : null;
}


export async function fetchCities(): Promise<any> {
  const token = getToken();
  const res = await fetch(API_CITY_URL, {
    headers: { Authorization: `Bearer ${token}` },
    cache: 'no-store',
  });
  if (!res.ok) throw new Error('Failed to fetch cities');
  return res.json();
}

export async function fetchTripTypes(): Promise<any> {
  const token = getToken();
  const res = await fetch(API_TRIP_TYPE_URL, {
    headers: { Authorization: `Bearer ${token}` },
    cache: 'no-store',
  });
  if (!res.ok) throw new Error('Failed to fetch cities');
  return res.json();
}


//
// ─── USERS ─────────────────────────────────────────────────────────────────────────
//

/**
 * Check if an email is already registered. Returns { exists: boolean, user } on success.
 */
export async function checkEmail(email: string): Promise<{ exists: boolean; user?: any }> {
  const token = getToken();
  const res = await fetch(`${API_BASE_URL}/admin/users/check-email`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: token ? `Bearer ${token}` : '',
    },
    body: JSON.stringify({ email: email.trim() }),
  });
  if (!res.ok) throw new Error('Failed to check email');
  return res.json();
}

/**
 * Create a new user. Expects { name, email, phone } in the body. Returns the created user object.
 */
export async function createUser(data: {
  name: string;
  email: string;
  phone: string;
}): Promise<any> {
  const token = getToken();
  const res = await fetch(`${API_BASE_URL}/admin/users`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: token ? `Bearer ${token}` : '',
    },
    body: JSON.stringify({
      name: data.name.trim(),
      email: data.email.trim(),
      phone: data.phone.trim(),
    }),
  });
  if (!res.ok) throw new Error('Failed to create user');
  return res.json();
}

//
// ─── ADDRESSES ─────────────────────────────────────────────────────────────────────
//

/**
 * Create an address for the user. Expects { user_id, type, address } in the body.
 * Returns the created address object (including lat_long if your backend does that).
 */
export async function createAddress(data: {
  userId: number;
  type: 'PICKUP' | 'DROP';
  address: string;
}): Promise<any> {
  const token = getToken();
  const res = await fetch(`${API_BASE_URL}/addresses`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: token ? `Bearer ${token}` : '',
    },
    body: JSON.stringify({
      userId: data.userId,
      type: data.type,
      address: data.address.trim(),
    }),
  });
  if (!res.ok) throw new Error(`Failed to create ${data.type} address`);
  return res.json();
}

//
// ─── BOOKINGS ──────────────────────────────────────────────────────────────────────
//

export async function createBooking(data: {
  userId: number;
  pickupAddressId: string;
  dropAddressId: string;
  fromCityId: number;
        toCityId: number;
  vehicleId: number | null;
  pickupDateTime: string;
  pickupLatLong?: string;
  dropLatLong?: string;
  tripTypeId?:number;
  fare?:number| null;
}): Promise<any> {
  const token = getToken();
  const res = await fetch(`${API_BASE_URL}/bookings`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: token ? `Bearer ${token}` : '',
    },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error('Failed to create booking');
  return res.json();
}

//
// ─── VEHICLES ──────────────────────────────────────────────────────────────────────
//

/**
 * Fetch list of all available vehicles. Returns an array of vehicle objects.
 */
export async function fetchVehicles(): Promise<any[]> {
  const token = getToken();
  const res = await fetch(`${API_BASE_URL}/vehicles`, {
    headers: {
      'Content-Type': 'application/json',
      Authorization: token ? `Bearer ${token}` : '',
    },
    cache: 'no-store',
  });
  if (!res.ok) throw new Error('Failed to fetch vehicles');
  return res.json();
}

//
// ─── PLACES / AUTOCOMPLETE ──────────────────────────────────────────────────────────
//

/**
 * Fetch address suggestions (Google Places Autocomplete). Returns an array of { description, place_id }.
 */
export async function fetchPlaceAutocomplete(
  input: string,
  sessiontoken: string
): Promise<{ description: string; place_id: string }[]> {
  const token = getToken();
  const encoded = encodeURIComponent(input);
  const res = await fetch(
    `${API_BASE_URL}/places/autocomplete?input=${encoded}&sessiontoken=${sessiontoken}`,
    {
      headers: {
        'Content-Type': 'application/json',
        Authorization: token ? `Bearer ${token}` : '',
      },
    }
  );
  if (!res.ok) throw new Error('Failed to fetch place suggestions');
  return res.json();
}


//
// ─── (G) FETCH ALL BOOKINGS ────────────────────────────────────────────────────────
//
export async function fetchBookings(): Promise<any[]> {
  const token = getToken();
  const res = await fetch(`${API_BASE_URL}/bookings`, {
    headers: {
      'Content-Type': 'application/json',
      Authorization: token ? `Bearer ${token}` : '',
    },
    cache: 'no-store',
  });
  if (!res.ok) throw new Error('Failed to fetch bookings');
  return res.json();
}

//
// ─── (H) FETCH A SINGLE BOOKING BY ID ───────────────────────────────────────────────
//
export async function fetchBookingById(
  bookingId: number
): Promise<any> {
  const token = getToken();
  const res = await fetch(`${API_BASE_URL}/bookings/${bookingId}`, {
    headers: {
      'Content-Type': 'application/json',
      Authorization: token ? `Bearer ${token}` : '',
    },
  });
  if (!res.ok) throw new Error(`Failed to fetch booking #${bookingId}`);
  return res.json();
}

//
// ─── (I) UPDATE A BOOKING ──────────────────────────────────────────────────────────
//
export async function updateBooking(data: {
  bookingId: number;
  userId?: number;
  vehicleId?: number;
  fromCityId?: number;
  toCityId?: number;
  pickupAddressId?: string;
  dropAddressId?: string;
  pickupDateTime?: string;
  tripTypeId?: number;
  fare?: number;
}): Promise<any> {
  const token = getToken();
  const { bookingId, ...rest } = data;
  const payload: any = {};
  if (rest.userId !== undefined) payload.user_id = rest.userId;
  if (rest.vehicleId !== undefined) payload.vehicle_id = rest.vehicleId;
  if (rest.fromCityId !== undefined) payload.from_city_id = rest.fromCityId;
  if (rest.toCityId !== undefined) payload.to_city_id = rest.toCityId;
  if (rest.pickupAddressId !== undefined) payload.pickup_address_id = rest.pickupAddressId;
  if (rest.dropAddressId !== undefined) payload.drop_address_id = rest.dropAddressId;
  if (rest.pickupDateTime !== undefined) payload.pickup_date_time = rest.pickupDateTime;
  if (rest.tripTypeId !== undefined) payload.trip_type_id = rest.tripTypeId;
  if (rest.fare !== undefined) payload.fare = rest.fare;

  const res = await fetch(`${API_BASE_URL}/bookings/${bookingId}`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
      Authorization: token ? `Bearer ${token}` : '',
    },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(`Failed to update booking #${bookingId}`);
  return res.json();
}

//
// ─── (J) DELETE A BOOKING ──────────────────────────────────────────────────────────
//
export async function deleteBooking(bookingId: number): Promise<void> {
  const token = getToken();
  const res = await fetch(`${API_BASE_URL}/bookings/${bookingId}`, {
    method: 'DELETE',
    headers: {
      Authorization: token ? `Bearer ${token}` : '',
    },
  });
  if (!res.ok) throw new Error(`Failed to delete booking #${bookingId}`);
  return;
}

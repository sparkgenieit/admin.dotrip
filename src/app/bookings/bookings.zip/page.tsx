
import AdminBookingMainContent from './AdminBookingMainContent';

export default function Page() {
  return <AdminBookingMainContent />;
}

// src/app/bookings/BookingTimeForm.tsx
'use client';

import React, { useEffect, useState, useRef } from 'react';
import { fetchCities, fetchTripTypes } from '../service';

interface City {
  id: number;
  name: string;
  state: string;
}

interface TripType {
  id: number;
  label: string;
}

interface BookingData {
  tripTypeId: number;
  pickupLocation: string;   // "City, State" display
  pickupCityId: number;     // numeric ID
  dropLocation: string;     // "City, State" display
  dropCityId: number;       // numeric ID
  pickupDate: string;
  pickupTime: string;
}

export default function BookingTimeForm({
  onBookingDetailsChange,
}: {
  onBookingDetailsChange: (data: BookingData) => void;
}) {
  // ─── (1) TRIP TYPOLOGY STATES ──────────────────────────────────────────────
  const [tripTypeId, setTripTypeId] = useState<number>(0);
  const [tripTypes, setTripTypes] = useState<TripType[]>([]);

  // ─── (2) LOCATION / DATE / TIME STATES ─────────────────────────────────────
  const [pickupLocation, setPickupLocation] = useState('');
  const [pickupCityId, setPickupCityId] = useState<number | null>(null);
  const [dropLocation, setDropLocation] = useState('');
  const [dropCityId, setDropCityId] = useState<number | null>(null);
  const [pickupDate, setPickupDate] = useState('2025-05-05');
  const [pickupTime, setPickupTime] = useState('07:00');

  // ─── (3) CITY AUTOCOMPLETE STATES ─────────────────────────────────────────
  const [allCities, setAllCities] = useState<City[]>([]);
  const [showPickupSuggestions, setShowPickupSuggestions] = useState(false);
  const [showDropSuggestions, setShowDropSuggestions] = useState(false);
  const [errors, setErrors] = useState<{ pickup?: string; drop?: string }>({});

  // Fetch list of cities on mount
  useEffect(() => {
    async function fetchCitiesFromService() {
      try {
        const data: City[] = await fetchCities();
        setAllCities(data);
      } catch (err) {
        console.error('City fetch error:', err);
      }
    }
    fetchCitiesFromService();
  }, []);

  // Fetch list of trip types on mount
  useEffect(() => {
    async function fetchTripTypesFromService() {
      try {
        const data: TripType[] = await fetchTripTypes();
        setTripTypes(data);
        if (data.length > 0) {
          setTripTypeId(data[0].id); // default to first tripType if none selected yet
        }
      } catch (err) {
        console.error('Trip types fetch error:', err);
      }
    }
    fetchTripTypesFromService();
  }, []);

  // Filtered lists based on user input
  const filteredPickup = showPickupSuggestions
    ? allCities.filter((city) =>
        `${city.name}, ${city.state}`
          .toLowerCase()
          .includes(pickupLocation.toLowerCase())
      )
    : [];

  const filteredDrop = showDropSuggestions
    ? allCities.filter((city) =>
        `${city.name}, ${city.state}`.toLowerCase().includes(dropLocation.toLowerCase())
      )
    : [];

  // Handle form submission
  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const newErrors: typeof errors = {};
    if (!pickupLocation) newErrors.pickup = 'Pickup location required';
    if (!dropLocation) newErrors.drop = 'Drop location required';
    if (pickupCityId === null) newErrors.pickup = 'Please select a valid pickup city';
    if (dropCityId === null) newErrors.drop = 'Please select a valid drop city';
    setErrors(newErrors);
    if (Object.keys(newErrors).length === 0) {
      onBookingDetailsChange({
        tripTypeId,
        pickupLocation,
        pickupCityId: pickupCityId!,
        dropLocation,
        dropCityId: dropCityId!,
        pickupDate,
        pickupTime,
      });
    }
  }

  return (
    <div>
      <form className="grid md:grid-cols-6 gap-4" onSubmit={handleSubmit}>
        {/* Trip Type */}
        <div className="col-span-2">
          <label className="block text-sm font-medium">TRIP TYPE</label>
          <select
            value={tripTypeId}
            onChange={(e) => setTripTypeId(parseInt(e.target.value, 10))}
            className="w-full border rounded px-3 py-2"
          >
            {tripTypes.map((tt) => (
              <option key={tt.id} value={tt.id}>
                {tt.label}
              </option>
            ))}
          </select>
        </div>

        {/* Pickup */}
        <div className="col-span-2 relative">
          <label className="block text-sm font-medium">FROM</label>
          <input
            type="text"
            value={pickupLocation}
            onChange={(e) => {
              setPickupLocation(e.target.value);
              setPickupCityId(null);
            }}
            onFocus={() => setShowPickupSuggestions(true)}
            onBlur={() => setTimeout(() => setShowPickupSuggestions(false), 100)}
            className="w-full border rounded px-3 py-2"
            placeholder="Pickup location"
          />
          {errors.pickup && (
            <p className="text-red-600 text-xs mt-1">{errors.pickup}</p>
          )}
          {showPickupSuggestions && (
            <ul className="absolute z-50 bg-white border w-full max-h-40 overflow-y-auto">
              {filteredPickup.map((city) => {
                const display = `${city.name}, ${city.state}`;
                return (
                  <li
                    key={city.id}
                    onMouseDown={() => {
                      setPickupLocation(display);
                      setPickupCityId(city.id);
                    }}
                    className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
                  >
                    {display}
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        {/* Drop */}
        <div className="col-span-2 relative">
          <label className="block text-sm font-medium">TO</label>
          <input
            type="text"
            value={dropLocation}
            onChange={(e) => {
              setDropLocation(e.target.value);
              setDropCityId(null);
            }}
            onFocus={() => setShowDropSuggestions(true)}
            onBlur={() => setTimeout(() => setShowDropSuggestions(false), 100)}
            className="w-full border rounded px-3 py-2"
            placeholder="Drop location"
          />
          {errors.drop && (
            <p className="text-red-600 text-xs mt-1">{errors.drop}</p>
          )}
          {showDropSuggestions && (
            <ul className="absolute z-50 bg-white border w-full max-h-40 overflow-y-auto">
              {filteredDrop.map((city) => {
                const display = `${city.name}, ${city.state}`;
                return (
                  <li
                    key={city.id}
                    onMouseDown={() => {
                      setDropLocation(display);
                      setDropCityId(city.id);
                    }}
                    className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
                  >
                    {display}
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        {/* Pickup Date */}
        <div>
          <label className="block text-sm font-medium">DATE</label>
          <input
            type="date"
            value={pickupDate}
            onChange={(e) => setPickupDate(e.target.value)}
            className="w-full border rounded px-3 py-2"
          />
        </div>

        {/* Pickup Time */}
        <div>
          <label className="block text-sm font-medium">TIME</label>
          <input
            type="time"
            value={pickupTime}
            onChange={(e) => setPickupTime(e.target.value)}
            className="w-full border rounded px-3 py-2"
          />
        </div>

        {/* Submit */}
        <div className="md:col-span-6">
          <button
            type="submit"
            className="w-full bg-orange-600 hover:bg-orange-700 text-white py-3 rounded-md"
          >
            Search Cabs
          </button>
        </div>
      </form>
    </div>
  );
}

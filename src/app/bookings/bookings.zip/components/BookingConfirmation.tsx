'use client';

import React from 'react';

interface BookingDetails {
  pickupDateTime: string;
  fare: number;
  pickupAddress: string;
  dropAddress: string;
}

interface SelectedCar {
  name: string;
  price: number;
  image: string;
}

interface Props {
  bookingDetails: BookingDetails;
  selectedCar: SelectedCar;
}

export default function BookingConfirmation({ bookingDetails, selectedCar }: Props) {
  if (!bookingDetails || !selectedCar) return <p>Missing data</p>;

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-4">
      <div className="max-w-md w-full bg-white rounded-xl shadow p-6 space-y-4 text-center">
        <h1 className="text-2xl font-bold text-green-600">Booking Confirmed!</h1>

        {/* Booking details */}
        <div className="text-left space-y-2">
          <p>
            <span className="font-semibold">Pickup Address:</span>{' '}
            {bookingDetails.pickupAddress}
          </p>
          <p>
            <span className="font-semibold">Drop Address:</span>{' '}
            {bookingDetails.dropAddress}
          </p>
          <p>
            <span className="font-semibold">Date & Time:</span>{' '}
            {new Date(bookingDetails.pickupDateTime).toLocaleString()}
          </p>
          <p>
            <span className="font-semibold">Fare:</span> ₹{bookingDetails.fare}
          </p>
        </div>

        {/* Selected Car */}
        <div className="mt-4 text-left space-y-1">
          <h2 className="font-semibold">Selected Car:</h2>
          <p>{selectedCar.name}</p>
          <img
            src={`/cars/${selectedCar.image}`}
            alt={selectedCar.name}
            className="w-28 h-20 object-contain"
          />
          <p className="text-blue-600 font-bold">₹{selectedCar.price}</p>
        </div>

        <button
          onClick={() => window.location.href = '/'}
          className="mt-6 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded"
        >
          Back to Home
        </button>
      </div>
    </div>
  );
}

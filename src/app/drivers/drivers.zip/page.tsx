import DriversMainContent from './DriversMainContent';

export default function DriversPage() {
  return <DriversMainContent />;
}
export interface Driver {
  id?: number;
  name: string;
  license: string;
  userId: number;
  vendorId: number;
  vehicleId?: number;
}

export interface Vehicle {
  id: number;
  name: string;
  model: string;
}
export const metadata = { title: 'Drivers' };

export default function DriversLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
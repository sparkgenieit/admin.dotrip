'use client';

import { useEffect, useState } from 'react';
import {
  fetchDrivers,
  addDriver,
  updateDriver,
  deleteDriver,
  fetchVehicles
} from './service';
import { Driver, Vehicle } from './types';
import ConfirmDeleteModal from '@/components/ConfirmDeleteModal';
import TableActions from '@/components/TableActions';
import { useUser } from '@/hooks/useUser';

export default function DriversMainContent() {
  const { id: userId, role } = useUser();
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [formData, setFormData] = useState<Omit<Driver, 'id'>>({
    name: '',
    license: '',
    userId: userId || 0,
    vendorId: userId || 0,
    vehicleId: undefined,
  });
  const [editingId, setEditingId] = useState<number | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<number | null>(null);

  useEffect(() => {
    fetchDrivers().then(setDrivers);
  }, []);

  useEffect(() => {
    const filters: { vendorId?: number; driverId?: number } = {};
    if (role === 'VENDOR') filters.vendorId = userId;
    if (role === 'DRIVER') filters.driverId = userId;
    fetchVehicles(filters).then(setVehicles).catch(console.error);
  }, [userId, role]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId != null) {
      await updateDriver(editingId, formData);
    } else {
      await addDriver(formData);
    }
    setFormData({ name: '', license: '', userId: userId || 0, vendorId: userId || 0, vehicleId: undefined });
    setEditingId(null);
    setDrivers(await fetchDrivers());
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const val = type === 'number' ? Number(value) : value;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? Number(value) : value,
    }));
  };

  const startEdit = (d: Driver) => {
    setFormData({
      name: d.name,
      license: d.license,
      userId: d.userId,
      vendorId: d.vendorId,
      vehicleId: d.vehicleId,
    });
    setEditingId(d.id!);
  };

  const handleDelete = (id: number) => {
    setConfirmDeleteId(id);
  };

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold mb-4">Drivers</h1>
      <button
        onClick={() => { setFormData({ name: '', license: '', userId: userId||0, vendorId: userId||0, vehicleId: undefined }); setEditingId(null); }}
        className="mb-4 bg-green-600 text-white px-4 py-2 rounded"
      >
        Add Driver
      </button>

      <form onSubmit={handleSubmit} className="mb-6 space-y-4">
        <div>
          <label className="block mb-1">Name</label>
          <input
            name="name"
            type="text"
            className="border p-2 w-full"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label className="block mb-1">License #</label>
          <input
            name="license"
            type="text"
            className="border p-2 w-full"
            value={formData.license}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label className="block mb-1">Assigned Vehicle</label>
          <select
            name="vehicleId"
            className="border p-2 w-full"
            value={formData.vehicleId ?? ''}
            onChange={handleChange}
          >
            <option value="">— None —</option>
            {vehicles.map(v => (
              <option key={v.id} value={v.id}>
                {v.name} {v.model}
              </option>
            ))}
          </select>
        </div>
        <div className="flex gap-2">
          <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">
            {editingId != null ? 'Update Driver' : 'Add Driver'}
          </button>
          {editingId != null && (
            <button
              type="button"
              onClick={() => { setFormData({ name: '', license: '', userId: userId||0, vendorId: userId||0, vehicleId: undefined }); setEditingId(null); }}
              className="bg-gray-400 text-white px-4 py-2 rounded"
            >
              Cancel
            </button>
          )}
        </div>
      </form>

      <table className="min-w-full bg-white border">
        <thead className="bg-gray-100">
          <tr>
            <th className="px-4 py-2 text-left">Name</th>
            <th className="px-4 py-2 text-left">License</th>
            <th className="px-4 py-2 text-left">Vehicle</th>
            <th className="px-4 py-2 text-left">Actions</th>
          </tr>
        </thead>
        <tbody>
          {drivers.map(d => (
            <tr key={d.id} className="border-t">
              <td className="px-4 py-2">{d.name}</td>
              <td className="px-4 py-2">{d.license}</td>
              <td className="px-4 py-2">
                {vehicles.find(v => v.id === d.vehicleId)?.name || '—'}
              </td>
              <td className="px-4 py-2">
                <TableActions
                  onEdit={() => startEdit(d)}
                  onDelete={() => handleDelete(d.id!)}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <ConfirmDeleteModal<Driver>
        itemId={confirmDeleteId}
        deleteFn={deleteDriver}
        setItems={setDrivers}
        isOpen={confirmDeleteId !== null}
        onCancel={() => setConfirmDeleteId(null)}
        title="Confirm Deletion"
        message="Are you sure you want to delete this driver?"
      />
    </div>
  );
}
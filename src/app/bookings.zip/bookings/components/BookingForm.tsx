
'use client';

import { useEffect, useState } from 'react';
import { fetchCities } from '../service';

interface BookingFormProps {
  onSearch: (params: {
    tripType: string;
    from: string;
    to: string;
    pickupDate: string;
    pickupTime: string;
  }) => void;
}

export default function BookingForm({ onSearch }: BookingFormProps) {
  const [tripType, setTripType] = useState("AIRPORT");
  const [pickupLocation, setPickupLocation] = useState("");
  const [dropLocation, setDropLocation] = useState("");
  const [pickupDate, setPickupDate] = useState("2025-05-05");
  const [pickupTime, setPickupTime] = useState("07:00");

  const [allCities, setAllCities] = useState<string[]>([]);
  const [showPickupSuggestions, setShowPickupSuggestions] = useState(false);
  const [showDropSuggestions, setShowDropSuggestions] = useState(false);
  const [errors, setErrors] = useState<{ pickup?: string; drop?: string }>({});

  useEffect(() => {
    async function fetchCitiesFromService() {
      try {
        const data = await fetchCities();
        const cityNames = data.map((city: any) => `${city.name}, ${city.state}`);
        setAllCities(cityNames);
      } catch (err) {
        console.error("City fetch error:", err);
      }
    }
    fetchCitiesFromService();
  }, []);

  const filteredPickup = showPickupSuggestions
    ? allCities.filter((city) =>
        city.toLowerCase().includes(pickupLocation.toLowerCase())
      )
    : [];

  const filteredDrop = showDropSuggestions
    ? allCities.filter((city) =>
        city.toLowerCase().includes(dropLocation.toLowerCase())
      )
    : [];

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const newErrors: typeof errors = {};
    if (!pickupLocation) newErrors.pickup = "Pickup location required";
    if (!dropLocation) newErrors.drop = "Drop location required";
    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      onSearch({
        tripType,
        from: pickupLocation,
        to: dropLocation,
        pickupDate,
        pickupTime,
      });
    }
  }

  return (
  <div>
    <h2 className="text-xl font-bold mb-4">Booking Form</h2>
    <form
      className="grid md:grid-cols-6 gap-4 relative z-10"
      onSubmit={handleSubmit}
    >
      <div className="col-span-2 relative">
        <label className="block text-sm font-medium text-gray-700">FROM</label>
        <input
          type="text"
          placeholder="Enter Pickup Location"
          className={`mt-1 block w-full border rounded text-black px-3 py-2 ${errors.pickup ? 'border-red-500' : 'border-gray-300'}`}
          value={pickupLocation}
          onChange={(e) => setPickupLocation(e.target.value)}
          onFocus={() => setShowPickupSuggestions(true)}
          onBlur={() => setTimeout(() => setShowPickupSuggestions(false), 100)}
        />
        {errors.pickup && (
          <p className="text-red-600 text-xs mt-1">{errors.pickup}</p>
        )}
        {showPickupSuggestions && (
          <ul className="absolute z-50 bg-white border border-gray-300 w-full mt-1 rounded max-h-40 overflow-y-auto shadow text-sm">
            {filteredPickup.map((city) => (
              <li
                key={`pickup-${city}`}
                className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
                onMouseDown={() => setPickupLocation(city)}
              >
                {city}
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="col-span-2 relative">
        <label className="block text-sm font-medium text-gray-700">TO</label>
        <input
          type="text"
          placeholder="Enter Drop Location"
          className={`mt-1 block w-full border rounded text-black px-3 py-2 ${errors.drop ? 'border-red-500' : 'border-gray-300'}`}
          value={dropLocation}
          onChange={(e) => setDropLocation(e.target.value)}
          onFocus={() => setShowDropSuggestions(true)}
          onBlur={() => setTimeout(() => setShowDropSuggestions(false), 100)}
        />
        {errors.drop && (
          <p className="text-red-600 text-xs mt-1">{errors.drop}</p>
        )}
        {showDropSuggestions && (
          <ul className="absolute z-50 bg-white border border-gray-300 w-full mt-1 rounded max-h-40 overflow-y-auto shadow text-sm">
            {filteredDrop.map((city) => (
              <li
                key={`drop-${city}`}
                className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
                onMouseDown={() => setDropLocation(city)}
              >
                {city}
              </li>
            ))}
          </ul>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Date</label>
        <input
          type="date"
          className="mt-1 block w-full border border-gray-300 rounded px-3 py-2 text-black"
          value={pickupDate}
          onChange={(e) => setPickupDate(e.target.value)}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Time</label>
        <input
          type="time"
          className="mt-1 block w-full border border-gray-300 rounded px-3 py-2 text-black"
          value={pickupTime}
          onChange={(e) => setPickupTime(e.target.value)}
        />
      </div>

      <div className="md:col-span-6">
        <button
          type="submit"
          className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 rounded-md"
        >
          Search Cabs
        </button>
      </div>
    </form>
  </div>
  );
}
